"""Plugin template for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_clipboard
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
from pathlib import Path
import sys
import webbrowser

from xml.etree import ElementTree as ET

from calendar import day_name, month_name

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


locale.setlocale(locale.LC_TIME, "")
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]



class ClipboardManager:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def _cut_element(self, event=None, elemPrefix=None):
        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.tv.tree.selection()[0]
        except:
            return

        if self._copy_element(elemPrefix) is None:
            return

        if self._ui.tv.tree.prev(node):
            self._ui.tv.go_to_node(self._ui.tv.tree.prev(node))
        else:
            self._ui.tv.go_to_node(self._ui.tv.tree.parent(node))
        self._mdl.delete_element(node)
        return 'break'

    def _copy_element(self, event=None, elemPrefix=None):
        try:
            node = self._ui.tv.tree.selection()[0]
        except:
            return

        nodePrefix = node[:2]
        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        elementContainers = {
            CHAPTER_PREFIX: (self._mdl.novel.chapters, 'CHAPTER'),
            SECTION_PREFIX: (self._mdl.novel.sections, 'SECTION'),
            PLOT_LINE_PREFIX: (self._mdl.novel.plotLines, 'ARC'),
            PLOT_POINT_PREFIX: (self._mdl.novel.plotPoints, 'POINT'),
            CHARACTER_PREFIX: (self._mdl.novel.characters, 'CHARACTER'),
            LOCATION_PREFIX: (self._mdl.novel.locations, 'LOCATION'),
            ITEM_PREFIX: (self._mdl.novel.items, 'ITEM'),
            PRJ_NOTE_PREFIX: (self._mdl.novel.projectNotes, 'PROJECTNOTE')
        }
        if not nodePrefix in elementContainers:
            return

        elementContainer, xmlTag = elementContainers[nodePrefix]
        element = elementContainer[node]
        xmlElement = ET.Element(xmlTag)
        element.to_xml(xmlElement)
        self._remove_references(xmlElement)

        if nodePrefix == CHAPTER_PREFIX:
            for scId in self._mdl.novel.tree.get_children(node):
                xmlSection = ET.SubElement(xmlElement, 'SECTION')
                self._mdl.novel.sections[scId].to_xml(xmlSection)
                self._remove_references(xmlSection)
        elif nodePrefix == PLOT_LINE_PREFIX:
            for ppId in self._mdl.novel.tree.get_children(node):
                xmlPlotPoint = ET.SubElement(xmlElement, 'POINT')
                self._mdl.novel.plotPoints[ppId].to_xml(xmlPlotPoint)
                self._remove_references(xmlPlotPoint)

        text = ET.tostring(xmlElement)
        self._ui.root.clipboard_clear()
        self._ui.root.clipboard_append(text)
        self._ui.root.update()
        return 'break'

    def _paste_element(self, event=None, elemPrefix=None):
        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.tv.tree.selection()[0]
        except:
            return

        try:
            text = self._ui.root.clipboard_get()
            xmlElement = ET.fromstring(text)
        except:
            return

        prefixes = {
            'CHAPTER': CHAPTER_PREFIX,
            'SECTION': SECTION_PREFIX,
            'ARC': PLOT_LINE_PREFIX,
            'POINT': PLOT_POINT_PREFIX,
            'CHARACTER': CHARACTER_PREFIX,
            'LOCATION': LOCATION_PREFIX,
            'ITEM': ITEM_PREFIX,
            'PROJECTNOTE': PRJ_NOTE_PREFIX
        }
        nodePrefix = prefixes.get(xmlElement.tag, None)
        if nodePrefix is None:
            return

        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        if nodePrefix == SECTION_PREFIX:
            typeStr = xmlElement.get('type', 0)
            if int(typeStr) > 1:
                elemCreator = self._mdl.add_stage
            else:
                elemCreator = self._mdl.add_section
            elemContainer = self._mdl.novel.sections
        else:
            elementControls = {
                CHAPTER_PREFIX: (self._mdl.add_chapter, self._mdl.novel.chapters),
                PLOT_LINE_PREFIX: (self._mdl.add_plot_line, self._mdl.novel.plotLines),
                PLOT_POINT_PREFIX: (self._mdl.add_plot_point, self._mdl.novel.plotPoints),
                CHARACTER_PREFIX: (self._mdl.add_character, self._mdl.novel.characters),
                LOCATION_PREFIX: (self._mdl.add_location, self._mdl.novel.locations),
                ITEM_PREFIX: (self._mdl.add_item, self._mdl.novel.items),
                PRJ_NOTE_PREFIX: (self._mdl.add_project_note, self._mdl.novel.projectNotes)
            }
            if not nodePrefix in elementControls:
                return

            elemCreator, elemContainer = elementControls[nodePrefix]

        elemId = elemCreator(targetNode=node)
        if not elemId:
            return

        elemContainer[elemId].from_xml(xmlElement)

        if nodePrefix == CHAPTER_PREFIX:
            for xmlSection in xmlElement.iterfind('SECTION'):
                typeStr = xmlSection.get('type', 0)
                if int(typeStr) > 1:
                    scId = self._mdl.add_stage(targetNode=elemId)
                else:
                    scId = self._mdl.add_section(targetNode=elemId)
                self._mdl.novel.sections[scId].from_xml(xmlSection)
        elif nodePrefix == PLOT_LINE_PREFIX:
            for xmlPoint in xmlElement.iterfind('POINT'):
                ppId = self._mdl.add_plot_point(targetNode=elemId)
                self._mdl.novel.plotPoints[ppId].from_xml(xmlPoint)

        self._ctrl.refresh_views()
        self._ui.tv.go_to_node(elemId)
        return 'break'

    def _remove_references(self, xmlElement):
        references = [
            'Characters',
            'Locations',
            'Items',
            'PlotlineNotes',
            'Sections',
            'Section',
        ]
        for ref in references:
            for xmlRef in xmlElement.findall(ref):
                xmlElement.remove(xmlRef)
from tkinter import ttk


class ClipboardOperation:

    def __init__(self, view, text, icon, shortcut, command):
        self._ui = view
        self._toolbarButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=text,
            image=icon,
            command=command
            )
        self._toolbarButton.pack(side='left')
        self._toolbarButton.image = icon

        self._ui.tv.tree.bind(shortcut, command)

    def disable(self):
        self._toolbarButton.config(state='disabled')

    def enable(self):
        self._toolbarButton.config(state='normal')
from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
import tkinter as tk

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_clipboard', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


class Plugin(PluginBase):
    """Clipboard plugin class.
    
    Public class constants:
        VERSION: str -- Version string.
        API_VERSION: str -- API compatibility indicator.
        DESCRIPTION: str -- Description to be diplayed in the novelibre plugin list.
        URL: str -- Plugin project homepage URL.

    Public instance variables:
        filePath: str -- Location of the installed plugin.
        isActive: Boolean -- Acceptance flag.
        isRejected: Boolean --  Rejection flag.
    """
    VERSION = '0.7.0'
    API_VERSION = '4.3'
    DESCRIPTION = 'A clipboard plugin'
    URL = 'https://github.com/peter88213/nv_clipboard'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_clipboard/'

    def disable_menu(self):
        """Disable toolbar buttons when no project is open.
        
        Overrides the superclass method.
        """
        self._copy.disable()
        self._paste.disable()

    def enable_menu(self):
        """Enable toolbar buttons when a project is open.
        
        Overrides the superclass method.
        """
        self._cut.enable()
        self._copy.enable()
        self._paste.enable()

    def install(self, model, view, controller, prefs=None):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """

        view.helpMenu.add_command(label=_('Clipboard Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        clipboardManager = ClipboardManager(model, view, controller)


        prefs = controller.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            cutIcon = tk.PhotoImage(file=f'{iconPath}/cut.png')
        except:
            cutIcon = None
        try:
            copyIcon = tk.PhotoImage(file=f'{iconPath}/copy.png')
        except:
            copyIcon = None
        try:
            pasteIcon = tk.PhotoImage(file=f'{iconPath}/paste.png')
        except:
            pasteIcon = None

        tk.Frame(view.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._cut = ClipboardOperation(view, _('Cut'), cutIcon, '<Control-x>', clipboardManager._cut_element)
        self._copy = ClipboardOperation(view, _('Copy'), copyIcon, '<Control-c>', clipboardManager._copy_element)
        self._paste = ClipboardOperation(view, _('Paste'), pasteIcon, '<Control-v>', clipboardManager._paste_element)

    def lock(self):
        """Inhibit changes on the model.
        
        Overrides the superclass method.
        """
        self._paste.disable()

    def unlock(self):
        """Enable changes on the model.
        
        Overrides the superclass method.
        """
        self._paste.enable()
