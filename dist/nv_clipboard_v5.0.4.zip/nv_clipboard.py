"""Plugin template for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_clipboard
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
from tkinter import ttk
import webbrowser

from xml.etree import ElementTree as ET



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
from datetime import date
from datetime import time
import os

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



class ClipboardManager(ServiceBase):

    def cut_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        if self.copy_element(elemPrefix) is None:
            return

        if self._ui.tv.tree.prev(node):
            self._ui.tv.go_to_node(self._ui.tv.tree.prev(node))
        else:
            self._ui.tv.go_to_node(self._ui.tv.tree.parent(node))
        self._mdl.delete_element(node, trash=False)
        return 'break'

    def copy_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        nodePrefix = node[:2]
        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        elementContainers = {
            CHAPTER_PREFIX: (self._mdl.novel.chapters, 'CHAPTER'),
            SECTION_PREFIX: (self._mdl.novel.sections, 'SECTION'),
            PLOT_LINE_PREFIX: (self._mdl.novel.plotLines, 'ARC'),
            PLOT_POINT_PREFIX: (self._mdl.novel.plotPoints, 'POINT'),
            CHARACTER_PREFIX: (self._mdl.novel.characters, 'CHARACTER'),
            LOCATION_PREFIX: (self._mdl.novel.locations, 'LOCATION'),
            ITEM_PREFIX: (self._mdl.novel.items, 'ITEM'),
            PRJ_NOTE_PREFIX: (self._mdl.novel.projectNotes, 'PROJECTNOTE')
        }
        if not nodePrefix in elementContainers:
            return

        elementContainer, xmlTag = elementContainers[nodePrefix]
        element = elementContainer[node]
        xmlElement = ET.Element(xmlTag)
        element.to_xml(xmlElement)
        self._remove_references(xmlElement)

        if nodePrefix == CHAPTER_PREFIX:
            for scId in self._mdl.novel.tree.get_children(node):
                xmlSection = ET.SubElement(xmlElement, 'SECTION')
                self._mdl.novel.sections[scId].to_xml(xmlSection)
                self._remove_references(xmlSection)
        elif nodePrefix == PLOT_LINE_PREFIX:
            for ppId in self._mdl.novel.tree.get_children(node):
                xmlPlotPoint = ET.SubElement(xmlElement, 'POINT')
                self._mdl.novel.plotPoints[ppId].to_xml(xmlPlotPoint)
                self._remove_references(xmlPlotPoint)

        text = ET.tostring(xmlElement)
        self._ui.root.clipboard_clear()
        self._ui.root.clipboard_append(text)
        self._ui.root.update()
        return 'break'

    def paste_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        try:
            text = self._ui.root.clipboard_get()
            xmlElement = ET.fromstring(text)
        except:
            return

        prefixes = {
            'CHAPTER': CHAPTER_PREFIX,
            'SECTION': SECTION_PREFIX,
            'ARC': PLOT_LINE_PREFIX,
            'POINT': PLOT_POINT_PREFIX,
            'CHARACTER': CHARACTER_PREFIX,
            'LOCATION': LOCATION_PREFIX,
            'ITEM': ITEM_PREFIX,
            'PROJECTNOTE': PRJ_NOTE_PREFIX
        }
        nodePrefix = prefixes.get(xmlElement.tag, None)
        if nodePrefix is None:
            return

        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        if nodePrefix == SECTION_PREFIX:
            typeStr = xmlElement.get('type', 0)
            if int(typeStr) > 1:
                elemCreator = self._mdl.add_new_stage
            else:
                elemCreator = self._mdl.add_new_section
            elemContainer = self._mdl.novel.sections
        else:
            elementControls = {
                CHAPTER_PREFIX: (self._mdl.add_new_chapter, self._mdl.novel.chapters),
                PLOT_LINE_PREFIX: (self._mdl.add_new_plot_line, self._mdl.novel.plotLines),
                PLOT_POINT_PREFIX: (self._mdl.add_new_plot_point, self._mdl.novel.plotPoints),
                CHARACTER_PREFIX: (self._mdl.add_new_character, self._mdl.novel.characters),
                LOCATION_PREFIX: (self._mdl.add_new_location, self._mdl.novel.locations),
                ITEM_PREFIX: (self._mdl.add_new_item, self._mdl.novel.items),
                PRJ_NOTE_PREFIX: (self._mdl.add_new_project_note, self._mdl.novel.projectNotes)
            }
            if not nodePrefix in elementControls:
                return

            elemCreator, elemContainer = elementControls[nodePrefix]

        elemId = elemCreator(targetNode=node)
        if not elemId:
            return

        elemContainer[elemId].from_xml(xmlElement)

        if nodePrefix == CHAPTER_PREFIX:
            for xmlSection in xmlElement.iterfind('SECTION'):
                typeStr = xmlSection.get('type', 0)
                if int(typeStr) > 1:
                    scId = self._mdl.add_new_stage(targetNode=elemId)
                else:
                    scId = self._mdl.add_new_section(targetNode=elemId)
                self._mdl.novel.sections[scId].from_xml(xmlSection)
        elif nodePrefix == PLOT_LINE_PREFIX:
            for xmlPoint in xmlElement.iterfind('POINT'):
                ppId = self._mdl.add_new_plot_point(targetNode=elemId)
                self._mdl.novel.plotPoints[ppId].from_xml(xmlPoint)

        self._ctrl.refresh_tree()
        self._ui.tv.go_to_node(elemId)
        return 'break'

    def _remove_references(self, xmlElement):
        references = [
            'Characters',
            'Locations',
            'Items',
            'PlotlineNotes',
            'Sections',
            'Section',
        ]
        for ref in references:
            for xmlRef in xmlElement.findall(ref):
                xmlElement.remove(xmlRef)
import gettext
import locale
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_clipboard', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

import platform



class GenericKeys:

    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')


class MacKeys(GenericKeys):

    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    PASTE = ('<Command-v>', 'Cmd-V')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = GenericKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

import tkinter as tk


class Plugin(PluginBase):
    """Clipboard plugin class.
    
    Public class constants:
        VERSION: str -- Version string.
        API_VERSION: str -- API compatibility indicator.
        DESCRIPTION: str -- Description to be diplayed in the novelibre plugin list.
        URL: str -- Plugin project homepage URL.

    Public instance variables:
        filePath: str -- Location of the installed plugin.
        isActive: Boolean -- Acceptance flag.
        isRejected: Boolean --  Rejection flag.
    """
    VERSION = '5.0.4'
    API_VERSION = '5.0'
    DESCRIPTION = 'A clipboard plugin'
    URL = 'https://github.com/peter88213/nv_clipboard'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_clipboard/'

    def cut_element(self, event=None):
        self.clipboardManager.cut_element()

    def copy_element(self, event=None):
        self.clipboardManager.copy_element()

    def disable_menu(self):
        """Disable toolbar buttons when no project is open.
        
        Overrides the superclass method.
        """
        self.cutButton.config(state='disabled')
        self.copyButton.config(state='disabled')
        self.pasteButton.config(state='disabled')

    def enable_menu(self):
        """Enable toolbar buttons when a project is open.
        
        Overrides the superclass method.
        """
        self.cutButton.config(state='normal')
        self.copyButton.config(state='normal')
        self.pasteButton.config(state='normal')

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._ui.helpMenu.add_command(label=_('Clipboard Online help'), command=self.open_help)

        self.clipboardManager = ClipboardManager(model, view, controller)

        self._ui.tv.tree.bind(KEYS.CUT[0], self.cut_element)
        self._ui.tv.tree.bind(KEYS.COPY[0], self.copy_element)
        self._ui.tv.tree.bind(KEYS.PASTE[0], self.paste_element)


        prefs = controller.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            cutIcon = tk.PhotoImage(file=f'{iconPath}/cut.png')
        except:
            cutIcon = None
        try:
            copyIcon = tk.PhotoImage(file=f'{iconPath}/copy.png')
        except:
            copyIcon = None
        try:
            pasteIcon = tk.PhotoImage(file=f'{iconPath}/paste.png')
        except:
            pasteIcon = None

        tk.Frame(self._ui.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self.cutButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=f"{_('Cut')} ({KEYS.CUT[1]})",
            image=cutIcon,
            command=self.cut_element
            )
        self.cutButton.pack(side='left')
        self.cutButton.image = cutIcon

        self.copyButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=f"{_('Copy')} ({KEYS.COPY[1]})",
            image=copyIcon,
            command=self.copy_element
            )
        self.copyButton.pack(side='left')
        self.copyButton.image = copyIcon

        self.pasteButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=f"{_('Paste')} ({KEYS.PASTE[1]})",
            image=pasteIcon,
            command=self.paste_element
            )
        self.pasteButton.pack(side='left')
        self.pasteButton.image = pasteIcon

        if not prefs['enable_hovertips']:
            return

        try:
            from idlelib.tooltip import Hovertip
        except ModuleNotFoundError:
            return

        Hovertip(self.cutButton, self.cutButton['text'])
        Hovertip(self.copyButton, self.copyButton['text'])
        Hovertip(self.pasteButton, self.pasteButton['text'])

    def lock(self):
        """Inhibit changes on the model.
        
        Overrides the superclass method.
        """
        self.cutButton.config(state='disabled')
        self.pasteButton.config(state='disabled')

    def on_close(self):
        self.disable_menu()

    def open_help(self):
        webbrowser.open(self.HELP_URL)

    def paste_element(self, event=None):
        self.clipboardManager.paste_element()

    def unlock(self):
        """Enable changes on the model.
        
        Overrides the superclass method.
        """
        self.cutButton.config(state='normal')
        self.pasteButton.config(state='normal')

